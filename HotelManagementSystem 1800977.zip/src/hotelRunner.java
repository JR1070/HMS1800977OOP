
//*****************************//
//*SID:1800977			      *//
//*Date: 16/05/2020           *//
//*Description: a program     *//
//*which allows a user to     *//
//*log in and create a booking*//
//*via GUI. It will also allow*//
//*a manager to log in, using *//
//*a user name and password	  *//
//* prompt.					  *//
//*****************************//
import javax.swing.JFrame;

public class hotelRunner {
	// instantiating the class myHMS
	private static myHMS myHMS;

	public static void main(String[] args) {
		myHMS = new myHMS();
		myHMS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myHMS.setSize(1200, 400);
		myHMS.setVisible(true);
	}

}// end class