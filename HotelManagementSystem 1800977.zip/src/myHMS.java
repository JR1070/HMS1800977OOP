
//*****************************//
//*SID:1800977			      *//
//*Date: 16/05/2020           *//
//*Description: a program     *//
//*which allows a user to     *//
//*log in and create a booking*//
//*via GUI. It will also allow*//
//*a manager to log in, using *//
//*a user name and password	  *//
//* prompt.					  *//
//*****************************//

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

// main class here initialises and instantiates all layouts, JFrames strings, booleans, Text fields and panels for the GUI's use.
// Using the "extends" word here is used to alter the behaviour of the class.

public class myHMS extends JFrame implements ActionListener {
	/**
	 * 
	 */
	// serialVersionUID here is to associate each serialisable class version number
	private static final long serialVersionUID = 1L;
	private FlowLayout theFlowLayout1 = new FlowLayout();
	private BorderLayout theBorderLayout2 = new BorderLayout();
	private FlowLayout theFlowLayout3 = new FlowLayout();
	private FlowLayout theFlowLayout4 = new FlowLayout();
	private BorderLayout theBorderLayout3 = new BorderLayout();
	private BorderLayout theBorderLayout3B = new BorderLayout();
	private BorderLayout theBorderLayout_booking1; // for booking panel 1
	private FlowLayout theFlowLayout_booking1; // for booking frame
	private BorderLayout theBorderLayout_booking2; // for apartments panel (booking panel 2)
	private BorderLayout theBorderLayout_booking3; // for booking selections panel (booking panel 3); it is split into
													// A: labels and B: text fields
	private FlowLayout theFlowLayout_booking3; // for booking selections panel (booking panel 3);
	private JPanel thePanel1 = new JPanel();
	private JPanel thePanel2 = new JPanel();
	private JPanel thePanel2B = new JPanel();
	private JPanel thePanel3 = new JPanel();

	private JPanel thePanel_booking1;
	private JPanel thePanel_booking3;
	private JPanel thePanel_booking3A;
	private JPanel thePanel_booking3B;
	private JPanel thePanel_booking2;

	// apartments labels initialised here
	private JLabel theAptSelectionLabel;
	private JLabel theFirstNameLabel;
	private JLabel theLastNameLabel;
	private JLabel theMaxGuestsLabel;
	private JLabel theCateringBookingLabel;
	private JLabel theStartDateLabel;
	private JLabel theEndDateLabel;
	// all text fields for "make booking" interface
	private JTextField theAptSelectionTextField;
	private JTextField theFirstNameTextField;
	private JTextField theLastNameTextField;
	private JTextField theMaxGuestsTextField;
	private JTextField theCateringBookingTextField;
	private JTextField theStartDateTextField;
	private JTextField theEndDateTextField;
	// labels for logging are instantiated
	private JLabel theLoginLabel = new JLabel();
	private JLabel theUsernameLabel = new JLabel();
	private JLabel thePasswordLabel = new JLabel();

	// JLabels for the Client Options
	private JLabel clientMenuOptionsLabel;
	// JTextField for the Client Options
	private JTextField clientMenuOptionsTextField;

	// javax.swing.Font for Client Menu Options
	private Font aClientFont;
	private Font aManagerFont;
	// JLabels for the Manager Options
	private JLabel managerMenuOptionsLabel;
	// JTextField for the Manager Options
	private JTextField managerMenuOptionsTextField;
	// Text fields for each field where a user can input information
	private JTextField theLoginTextField = new JTextField();
	private JTextField theUsernameTextField = new JTextField();
	private JTextField thePasswordTextField = new JTextField();
	private String theLoginOptionNumber = "";
	private String theUsernameText = "";
	private String passwordText = "";

	private boolean login = false;
	private int loginCounter = 0;
	private boolean clientMenuDisplayed = false;
	private boolean clientBookingWriteReady = false;

	// Login Details for Clients, here two clients are able to log in
	private String[][] clientLoginDetails = { { "Client", "1234" }, { "Johnny", "joe*" } };
	private String tempClientUsername = "";
	private String tempClientPassword = "";

	// Login Details for Managers, here two managers have login details
	private String[][] managerLoginDetails = { { "Manager", "12345" }, { "Manager 2", "m4nager" } };
	private String tempManagerUsername = "";
	private String tempManagerPassword = "";

	private JFrame theBookingFrame;

	private XMLApartmentsReader theApartmentsReader;
	// Strings here are related to the information which will be displayed when the
	// Manager has logged in
	private String[][] theApartmentsData = new String[10][9];
	private String column[] = { "Apartment ID", "Apartment Name", "Price per Night", "Start Date", "End Date",
			"Max Guests", "Number Beds", "Number Baths", "Living Room" };

	private JPanel theDisplayPanel;
	private JFrame theDisplayFrame;
	private Document writeDoc;
	private xmlBookingWriter theXMLBookingWriter;

	private String aClientBookingAptName = "";
	private String aClientBookingFirstName = "";
	private String aClientBookingLastName = "";
	private String aClientBookingMaxGuests = "";
	private String aClientBookingStartDate = "";
	private String aClientBookingEndDate = "";
	private String aClientBookingCatering = "";

	private JButton theBookingButton;
	// =======================================================================================================================================================//

	// no-argument constructor here is used for the GUI
	public myHMS() {
		super("Hotel Java Deluxe");
		// instantiating the FlowLayout/BorderLayout of the GUI
		theFlowLayout1 = new FlowLayout();
		theBorderLayout2 = new BorderLayout();
		theBorderLayout2.setHgap(10);
		theBorderLayout2.setVgap(10);
		theFlowLayout3 = new FlowLayout();
		theFlowLayout4 = new FlowLayout();
		theBorderLayout3 = new BorderLayout();
		theBorderLayout3B = new BorderLayout();
		// Login Label here shows the Label and the text field where the client or
		// manager can enter their unique number (1 or 2)
		theLoginLabel = new JLabel("Login Options (1: Client, 2: Manager)");
		theLoginTextField = new JTextField(50); // Text field here can take up to 50 characters
		theLoginTextField.addActionListener(this);
		// layout will use theFlowLayout1
		setLayout(theFlowLayout1);

		thePanel1 = new JPanel();
		thePanel2 = new JPanel();
		thePanel2B = new JPanel();
		thePanel3 = new JPanel();

		thePanel1.setLayout(theBorderLayout2);
		thePanel1.setVisible(true);
		this.add(thePanel1);
		thePanel2.setLayout(theBorderLayout3);
		thePanel2.setVisible(true);
		thePanel2B.setLayout(theBorderLayout3B);
		thePanel2B.setVisible(true);
		thePanel1.add(thePanel2, BorderLayout.EAST);
		this.add(thePanel1);
		thePanel1.add(thePanel2B, BorderLayout.WEST);
		this.add(thePanel1);

		thePanel3.setLayout(theFlowLayout4);
		thePanel3.setVisible(true);
		thePanel1.add(thePanel3, BorderLayout.SOUTH);
		this.add(thePanel1);

		theLoginLabel.setVisible(true);
		thePanel2B.add(theLoginLabel, BorderLayout.NORTH);
		thePanel2B.setVisible(true);
		thePanel1.add(thePanel2B, BorderLayout.WEST);
		this.add(thePanel1);

		theLoginTextField.setSize(100, 100);
		theLoginTextField.setVisible(true);
		thePanel2.add(theLoginTextField, BorderLayout.NORTH);
		thePanel2.setVisible(true);
		thePanel1.add(thePanel2, BorderLayout.EAST);
		this.add(thePanel1);
		// username labels/textfields here allow the user to enter their username (in
		// this case Client or Manager
		theUsernameLabel = new JLabel("Username:  ");
		theUsernameTextField = new JTextField(50);
		theUsernameTextField.addActionListener(this);

		theUsernameLabel.setVisible(true);
		thePanel2B.add(theUsernameLabel, BorderLayout.CENTER);
		thePanel2B.setVisible(true);
		thePanel1.add(thePanel2B, BorderLayout.WEST);
		this.add(thePanel1);
		// size of the text field here is the to 100 x 100 pixels
		theUsernameTextField.setSize(100, 100);
		// visibility of the usernameTextField is set to true ie visible as opposed to
		// false which would not make it visible
		theUsernameTextField.setVisible(true);
		thePanel2.add(theUsernameTextField, BorderLayout.CENTER);
		thePanel2.setVisible(true);
		thePanel1.add(thePanel2, BorderLayout.EAST);
		this.add(thePanel1);
		// Password label is instantiated here
		thePasswordLabel = new JLabel("Password:  ");
		thePasswordTextField = new JTextField(50);
		thePasswordTextField.addActionListener(this);

		thePasswordLabel.setVisible(true);
		thePanel2B.add(thePasswordLabel, BorderLayout.SOUTH);
		thePanel2B.setVisible(true);
		thePanel1.add(thePanel2B, BorderLayout.WEST);
		this.add(thePanel1);

		thePasswordTextField.setSize(100, 100);
		thePasswordTextField.setVisible(true);
		thePanel2.add(thePasswordTextField, BorderLayout.SOUTH);
		thePanel2.setVisible(true);
		thePanel1.add(thePanel2, BorderLayout.EAST);
		this.add(thePanel1);

		theAptSelectionLabel = new JLabel("Apartment Name");
		theAptSelectionTextField = new JTextField(15);
		theAptSelectionTextField.addActionListener(this);

		theFirstNameLabel = new JLabel("First Name");
		theFirstNameTextField = new JTextField(15);
		theFirstNameTextField.addActionListener(this);

		theLastNameLabel = new JLabel("Last  Name");
		theLastNameTextField = new JTextField(15);
		theLastNameTextField.addActionListener(this);

		theMaxGuestsLabel = new JLabel("Max Guests");
		theMaxGuestsTextField = new JTextField(15);
		theMaxGuestsTextField.addActionListener(this);

		theStartDateLabel = new JLabel("Start Date");
		theStartDateTextField = new JTextField(15);
		theStartDateTextField.addActionListener(this);

		theEndDateLabel = new JLabel("End Date");
		theEndDateTextField = new JTextField(15);
		theEndDateTextField.addActionListener(this);

		theCateringBookingLabel = new JLabel("Catering(Yes or No)");
		theCateringBookingTextField = new JTextField(15);
		theCateringBookingTextField.addActionListener(this);

		theDisplayFrame = new JFrame();
		theDisplayPanel = new JPanel();
	}

	// @Override
	public void actionPerformed(ActionEvent event) {

		theLoginOptionNumber = theLoginTextField.getText();

		// Debugging statement
		System.out.println(theLoginOptionNumber);

		theUsernameText = theUsernameTextField.getText();

		// Debugging statement
		System.out.println(theUsernameText);

		passwordText = thePasswordTextField.getText();
		// Debugging statement
		System.out.println(passwordText);

		while (login == false) {
			for (int i = 0; i < 2; i++) {
				tempClientUsername = clientLoginDetails[i][0];
				tempClientPassword = clientLoginDetails[i][1];

				tempManagerUsername = managerLoginDetails[i][0];
				tempManagerPassword = managerLoginDetails[i][1];

				// Debugging statement
				System.out.println("Gamer time! is:  " + tempClientUsername);
				if ((new String(theUsernameText).equals(tempClientUsername))
						& new String(passwordText).equals(tempClientPassword)
						& new String(theLoginOptionNumber).equals("1")) {
					System.out.println("Client Login Successful!");
					JOptionPane.showMessageDialog(null, "Client Login Successful");
					login = true;

					// Display the Client Options menu for clients
					StringBuilder buff = new StringBuilder();
					buff.append("<html><table>");
					buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "CLIENT OPTIONS"));
					buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "1. Do Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "2. Manage Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "3. EXIT"));
					buff.append("</table></html>");
					// setting font here
					aClientFont = new Font("Arial", Font.ITALIC, 24);

					clientMenuOptionsLabel = new JLabel(buff.toString());
					clientMenuOptionsLabel.setFont(aClientFont);
					thePanel3.add(clientMenuOptionsLabel, BorderLayout.NORTH);
					thePanel3.setVisible(true);
					thePanel1.add(thePanel3, BorderLayout.SOUTH);
					thePanel1.revalidate();
					thePanel1.repaint();
					this.add(thePanel1);

					clientMenuOptionsTextField = new JTextField(50);
					clientMenuOptionsTextField.addActionListener(this);
					thePanel3.add(clientMenuOptionsTextField, BorderLayout.SOUTH);
					thePanel3.setVisible(true);
					thePanel1.add(thePanel3, BorderLayout.SOUTH);
					thePanel1.revalidate();
					thePanel1.repaint();
					this.add(thePanel1);

					clientMenuDisplayed = true;

				} // end of if statement
				else if ((new String(theUsernameText).equals(tempManagerUsername))
						& new String(passwordText).equals(tempManagerPassword)
						& new String(theLoginOptionNumber).equals("2")) {
					System.out.println("Manager Login Successful!");
					JOptionPane.showMessageDialog(null, "Manager Login Successful");
					login = true;
					loginCounter = 3;

					// Display the Manager options here
				
					StringBuilder managerBuff = new StringBuilder();
					managerBuff.append("<html><table>");
					managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "MANAGER OPTIONS"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "1. View ALL Bookings"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "2. Manage a Booking"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "3. EXIT"));
					managerBuff.append("</table></html>");
					// setting font here
					aManagerFont = new Font("Arial", Font.ITALIC, 24);

					managerMenuOptionsLabel = new JLabel(managerBuff.toString());
					managerMenuOptionsLabel.setFont(aManagerFont);
					thePanel3.add(managerMenuOptionsLabel, BorderLayout.NORTH);
					thePanel3.setVisible(true);
					thePanel1.add(thePanel3, BorderLayout.SOUTH);
					thePanel1.revalidate();
					thePanel1.repaint();
					this.add(thePanel1);

					managerMenuOptionsTextField = new JTextField(50);
					managerMenuOptionsTextField.addActionListener(this);
				
					thePanel3.add(managerMenuOptionsTextField, BorderLayout.SOUTH);
					thePanel3.setVisible(true);
					thePanel1.add(thePanel3, BorderLayout.SOUTH);
					thePanel1.revalidate();
					thePanel1.repaint();
					this.add(thePanel1);
				} // end else if statement
				else {
					if ((loginCounter == 0) & (login == false)) {
						loginCounter = loginCounter + 1;
						JOptionPane.showMessageDialog(this, "Failed login. Check credentials!");
					}

				} // end else
			} // end for
		} // end while

		if (clientMenuDisplayed == true) {
			if (new String(clientMenuOptionsTextField.getText()).equals("1")) {
				// Debugging statement here
				System.out.println("Fun Debug Time!");

				theApartmentsReader = new XMLApartmentsReader();
				theXMLBookingWriter = new xmlBookingWriter();

				theApartmentsData = theApartmentsReader.apartmentsReader();

				// set up the new frame for the Booking
				theBookingFrame = new JFrame("Make Booking");
				theBookingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				theBookingFrame.setSize(1200, 500);
				theBookingFrame.setVisible(true);

				// Display the Booking Options for the user
				theFlowLayout_booking1 = new FlowLayout(); // Booking JFrame
				theBorderLayout_booking1 = new BorderLayout(); // booking panel 1
				theBorderLayout_booking2 = new BorderLayout(); // booking panel 2 for apartments viewing
				theBorderLayout_booking3 = new BorderLayout(); // booking panel 3 for booking selections
				theFlowLayout_booking3 = new FlowLayout(); // booking panel 3 for booking selections

				theBookingFrame.setLayout(theFlowLayout_booking1);

				thePanel_booking1 = new JPanel();
				thePanel_booking3 = new JPanel();
				thePanel_booking3A = new JPanel();
				thePanel_booking3B = new JPanel();
				thePanel_booking2 = new JPanel();

				thePanel_booking1.setLayout(theBorderLayout_booking1);
				theBookingFrame.add(thePanel_booking1);

				thePanel_booking2.setLayout(theBorderLayout_booking2);
				thePanel_booking2.setVisible(true);
				thePanel_booking1.add(thePanel_booking2, BorderLayout.NORTH);
				theBookingFrame.add(thePanel_booking1);

				thePanel_booking3.setLayout(theFlowLayout_booking3);
				theFlowLayout_booking3.setAlignment(FlowLayout.CENTER);
				thePanel_booking3.setVisible(true);
				thePanel_booking1.add(thePanel_booking3, BorderLayout.SOUTH);
				theBookingFrame.add(thePanel_booking1);

				theApartmentsReader.tableDisplay(theApartmentsData, column, thePanel_booking2, theBookingFrame);

				clientBookingWriteReady = true;

			}

		}

		if (clientBookingWriteReady == true) {

			// Apartment Selection, allows the user to select an apartment
			// ---------------------------------------------------------------//
			theAptSelectionLabel.setVisible(true);
			thePanel_booking3.add(theAptSelectionLabel, BorderLayout.NORTH);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theAptSelectionTextField.setSize(15, 15);
			theAptSelectionTextField.setVisible(true);
			thePanel_booking3.add(theAptSelectionTextField, BorderLayout.CENTER);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);
			// --------------------------------------------------------------//

			// First Name for booking Selection, allows a user to enter a name for the
			// booking
			// ---------------------------------------------------------------//
			theFirstNameLabel.setVisible(true);
			thePanel_booking3.add(theFirstNameLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theFirstNameTextField.setSize(20, 15);
			theFirstNameTextField.setVisible(true);
			thePanel_booking3.add(theFirstNameTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			// Last Name for booking Selection, allows a user to enter a surname for the
			// booking
			// ---------------------------------------------------------------//
			theLastNameLabel.setVisible(true);
			thePanel_booking3.add(theLastNameLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theLastNameTextField.setSize(15, 15);
			theLastNameTextField.setVisible(true);
			thePanel_booking3.add(theLastNameTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			// Max Guests for booking Selection, allows the user to enter how many guests
			// will be on the booking
			// ---------------------------------------------------------------//
			theMaxGuestsLabel.setVisible(true);
			thePanel_booking3.add(theMaxGuestsLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theMaxGuestsTextField.setSize(15, 15);
			theMaxGuestsTextField.setVisible(true);
			thePanel_booking3.add(theMaxGuestsTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			// Start Date for booking Selection, allows the user to enter a start date of
			// the booking
			// ---------------------------------------------------------------//
			theStartDateLabel.setVisible(true);
			thePanel_booking3.add(theStartDateLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theStartDateTextField.setSize(15, 15);
			theStartDateTextField.setVisible(true);
			thePanel_booking3.add(theStartDateTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			// End Date for booking Selection, allows the user to set an end date for the
			// booking
			// ---------------------------------------------------------------//
			theEndDateLabel.setVisible(true);
			thePanel_booking3.add(theEndDateLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theEndDateTextField.setSize(20, 15);
			theEndDateTextField.setVisible(true);
			thePanel_booking3.add(theEndDateTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			// Catering option for booking Selection, allows the user to select if they want
			// catering for their booking
			// ---------------------------------------------------------------//
			theCateringBookingLabel.setVisible(true);
			thePanel_booking3.add(theCateringBookingLabel);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theCateringBookingTextField.setSize(15, 15);
			theCateringBookingTextField.setVisible(true);
			thePanel_booking3.add(theCateringBookingTextField);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			theBookingButton = new JButton("Booking");
			theBookingButton.addActionListener(this);
			theBookingButton.setActionCommand("booking");
			theBookingButton.setVisible(true);
			thePanel_booking3.add(theBookingButton);
			thePanel_booking3.setVisible(true);
			thePanel_booking1.add(thePanel_booking3, BorderLayout.NORTH);
			theBookingFrame.add(thePanel_booking1);

			if ("booking".equals(event.getActionCommand())) {
				aClientBookingAptName = theAptSelectionTextField.getText();
				aClientBookingFirstName = theFirstNameTextField.getText();
				aClientBookingLastName = theLastNameTextField.getText();
				aClientBookingMaxGuests = theMaxGuestsTextField.getText();
				aClientBookingStartDate = theStartDateTextField.getText();
				aClientBookingEndDate = theEndDateTextField.getText();
				aClientBookingCatering = theCateringBookingTextField.getText();

				writeDoc = theXMLBookingWriter.serverConnection(); // creates a connection to the directory where the
																	// xml booking file will be edited and saved
				theXMLBookingWriter.bookingWriter(writeDoc,
						"C:\\Users\\Budl1ght\\Documents\\eclipse\\workspace\\HotelManager\\src\\testWriter.xml",
						aClientBookingAptName, aClientBookingFirstName, aClientBookingLastName, aClientBookingMaxGuests,
						aClientBookingStartDate, aClientBookingEndDate, aClientBookingCatering);

			}

		}

	}// end method

}// end class myHMS
