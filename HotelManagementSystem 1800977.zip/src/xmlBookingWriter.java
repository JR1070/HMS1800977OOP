
//*****************************//
//*SID:1800977			      *//
//*Date: 16/05/2020           *//
//*Description: a program     *//
//*which allows a user to     *//
//*log in and create a booking*//
//*via GUI. It will also allow*//
//*a manager to log in, using *//
//*a user name and password	  *//
//* prompt.					  *//
//*****************************//
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
// this class uses inheritance from the xmlWriter class, meaning that this is a subclass of xmlWriter
public class xmlBookingWriter extends xmlWriter {
	private Element rootElement;
	private Element theBooking;
	private Element theApartmentName;
	private Attr attr;
	private Element theFirstName;
	private Element theLastName;
	private Element theMaxGuests;
	private Element theStartDate;
	private Element theEndDate;
	private Element theCatering;
	private TransformerFactory transformerFactory;
	private Transformer transformer;
	private DOMSource source;
	private StreamResult result;
	private StreamResult consoleResult;
	private int BID = 101;

	// this bookingWriter class is used to write data inputted into the GUI text
	// fields to an xml file which is stored in a local xml file
	public void bookingWriter(Document doc, String filenameToWrite, String clientApartmentName, String clientFirstName,
			String clientLastName, String maxGuests, String bookingStartDate, String bookingEndDate,
			String bookingCatering) {
		try {
			// root element here
			rootElement = doc.createElement("clientsbookings");
			doc.appendChild(rootElement);

			// bookings element here
			theBooking = doc.createElement("clientbooking");
			rootElement.appendChild(theBooking);

			// setting attribute to element
			attr = doc.createAttribute("ID");

			// here you can randomise the booking ID generation for security purposes
			BID = BID + 1;
			attr.setValue(Integer.toString(BID));
			JOptionPane.showMessageDialog(null, "Your booking ID is:  " + BID);

			theBooking.setAttributeNode(attr);

			// bookings element
			theApartmentName = doc.createElement("apartmentname");
			theApartmentName.appendChild(doc.createTextNode(clientApartmentName));
			theBooking.appendChild(theApartmentName);

			// bookings element
			theFirstName = doc.createElement("firstname");
			theFirstName.appendChild(doc.createTextNode(clientFirstName));
			theBooking.appendChild(theFirstName);

			// bookings element
			theLastName = doc.createElement("lastname");
			theLastName.appendChild(doc.createTextNode(clientLastName));
			theBooking.appendChild(theLastName);

			// bookings element
			theMaxGuests = doc.createElement("numberguests");
			theMaxGuests.appendChild(doc.createTextNode(maxGuests));
			theBooking.appendChild(theMaxGuests);

			// bookings element
			theStartDate = doc.createElement("startdate");
			theStartDate.appendChild(doc.createTextNode(bookingStartDate));
			theBooking.appendChild(theStartDate);

			// bookings element
			theEndDate = doc.createElement("enddate");
			theEndDate.appendChild(doc.createTextNode(bookingEndDate));
			theBooking.appendChild(theEndDate);

			// bookings element
			theCatering = doc.createElement("catering");
			theCatering.appendChild(doc.createTextNode(bookingCatering));
			theBooking.appendChild(theCatering);

			// write the content into xml file
			transformerFactory = TransformerFactory.newInstance();
			transformer = transformerFactory.newTransformer();

			source = new DOMSource(doc);

			result = new StreamResult(new File(filenameToWrite));
			transformer.transform(source, result);

			// Output to console for testing of the class
			consoleResult = new StreamResult(System.out);
			transformer.transform(source, consoleResult);
		} catch (Exception e) {
			e.printStackTrace();
		} // end of try

	} // end of method

} // end of class
