
//*****************************//
//*SID:1800977			      *//
//*Date: 16/05/2020           *//
//*Description: a program     *//
//*which allows a user to     *//
//*log in and create a booking*//
//*via GUI. It will also allow*//
//*a manager to log in, using *//
//*a user name and password	  *//
//* prompt.					  *//
//*****************************//
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

// xmlReader class is started here
public abstract class xmlReader {
	private File inputFile;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;

	// serverConnection here is used to take the name of a location and attempts to
	// connect to it
	public Document serverConnection(String filename) {

		try {
			inputFile = new File(filename);
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			// doc = new Document(); //may cause error
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

		} catch (Exception e) {
			e.printStackTrace();
		} // end of catch
		return doc;

	}// end method
		// tableDisplay here is used by xmlApartmentsReader as it is inherited and
		// overridden in that class

	abstract void tableDisplay(String[][] aDataTable, String aColumn[], JPanel displayPanel, JFrame displayFrame);

}