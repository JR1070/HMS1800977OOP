
//*****************************//
//*SID:1800977			      *//
//*Date: 16/05/2020           *//
//*Description: a program     *//
//*which allows a user to     *//
//*log in and create a booking*//
//*via GUI. It will also allow*//
//*a manager to log in, using *//
//*a user name and password	  *//
//* prompt.					  *//
//*****************************//

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
// class starts here
public class xmlWriter {
	private DocumentBuilderFactory dbFactory;
	private DocumentBuilder dBuilder;
	private Document doc;
	// serverConnection here links to a local xml file where xml data will be written
	public Document serverConnection() {
		try {
			// create the three layers for the XML writer
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.newDocument();
		} catch (Exception e) {
			e.printStackTrace();
		} // end of try

		return doc;

	} // end of method

} // end of class
